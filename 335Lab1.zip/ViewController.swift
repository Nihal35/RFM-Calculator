//
//  ViewController.swift
//  lab1
//
//  Created by Janaka Balasooriya on 8/28/19.
//  Copyright © 2019 Janaka Balasooriya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

